package to.msn.wings.restaurantsystem;

public class SeatItem {
    private String s_id;
    private int s_capacity;
    private int o_id;

    public String getS_id() {
        return s_id;
    }

    public void setS_id(String s_id) {
        this.s_id = s_id;
    }

    public int getS_capacity() {
        return s_capacity;
    }

    public void setS_capacity(int s_capacity) {
        this.s_capacity = s_capacity;
    }

    public int getO_id() {
        return o_id;
    }

    public void setO_id(int o_id) {
        this.o_id = o_id;
    }
}
